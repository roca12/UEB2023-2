package co.edu.unbosque.springfirstapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFirstAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
