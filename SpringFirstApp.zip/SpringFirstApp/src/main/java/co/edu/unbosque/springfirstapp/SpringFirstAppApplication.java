package co.edu.unbosque.springfirstapp;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFirstAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFirstAppApplication.class, args);
	}
	
	//https://mkyong.com/java/how-to-send-http-request-getpost-in-java/ 

}
