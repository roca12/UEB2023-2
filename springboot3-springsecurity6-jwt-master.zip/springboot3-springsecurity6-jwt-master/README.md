# JWT Authentication and Authorization with Spring Boot 3 and Spring Security 6

Medium
Article: https://medium.com/@truongbui95/jwt-authentication-and-authorization-with-spring-boot-3-and-spring-security-6-2f90f9337421
