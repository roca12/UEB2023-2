/**
 * 
 */
/**
 * 
 */
module Prog2A {
}