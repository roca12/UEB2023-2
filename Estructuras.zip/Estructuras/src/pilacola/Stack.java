package pilacola;

public interface Stack<E> {

	void push(E info);

	E pop();

	int size();
}
