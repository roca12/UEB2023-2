package co.edu.unbosque.view;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6117540591733912503L;
	
	public VentanaPrincipal() {
		
	}

}
